#pragma once
#include <arch/x86_64/cpu/paging.h>
void KbdInitalize(virtaddr ioapicbase);